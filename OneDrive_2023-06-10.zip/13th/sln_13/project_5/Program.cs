﻿using System;

namespace project_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Child childA = new Child();
            Child childB = new Child("a");
        }
    }
}
