﻿using System;

namespace project_5
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
