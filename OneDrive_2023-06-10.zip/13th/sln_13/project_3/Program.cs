﻿using System;

namespace project_3
{
    class Program
    {
        static void Main(string[] args)
        {
            //상속했을 때 기본적인 생성자 호출 순서
            Child child = new Child(); //자식 인스턴스 생성

        }
    }
}
